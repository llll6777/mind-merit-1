import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-loaded Gemini Client to prevent crashes on startup if GEMINI_API_KEY is missing
let aiClient: GoogleGenAI | null = null;

function getAIClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY is not configured in the environment. Falling back to local responses.");
      return null;
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// REST API Endpoints
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    aiConfigured: !!process.env.GEMINI_API_KEY
  });
});

// AI Chatbot endpoint
app.post("/api/gemini/chat", async (req, res) => {
  const { message, history, language } = req.body;
  const isThai = language === 'th';

  const systemInstruction = `You are MIND MERIT's elite AI Mental Well-being Counselor, Psychologist, and Life Coach.
Your primary audience are teenagers, university students, and working adults experiencing exam stress, overthinking, loneliness, burnout, or work pressure.
You must always converse in the user's preferred language (${isThai ? 'Thai' : 'English'}).

IMPORTANT RULES:
1. NEVER diagnose clinical mental illness. You are here to educate, encourage, motivate, support, and coach.
2. If the user expresses thoughts of self-harm, severe clinical depression, or suicide, gently but firmly express care, validate their pain, and guide them to seek immediate professional medical attention (provide TH Hotline: 1323, EN Hotline: 988).
3. Be incredibly warm, compassionate, authentic, and calm. Combine the empathy of a Best Friend with the wisdom of a professional Psychologist.
4. DO NOT just dump long lists of advice. Be highly interactive, conversational, and light.
5. CRITICAL & MANDATORY: Always ask engaging, curious, open-ended questions back to the user to understand their situation better ("สงสัยอะไรให้ถาม"). If they give short answers, explore gently. For example, ask what made them feel that way, how their sleep has been, what their daily routines are, or what specific thoughts are bothering them. Make the conversation a true two-way dialogue rather than a one-sided advice engine.
6. Show extreme variety in your openings, coping strategy suggestions, and tone. Encourage them to explore (e.g., 'Would you like to try a quick 1-minute breathing game, or just talk about your day?').
7. Recommend actionable well-being exercises when appropriate (e.g., Box Breathing, mindfulness, physical movement, keeping a gratitude journal) but keep them bite-sized and ask for feedback.`;

  const ai = getAIClient();

  if (!ai) {
    // High-quality mock fallback response with high variety and follow-up questions
    let responseText = "";
    const msgLower = (message || "").toLowerCase();

    const thaiReplies = {
      stress: [
        "ผมเข้าใจความรู้สึกของคุณเลยครับ ความเครียดจากการสอบหรือภาระงานมันตึงและหนักมากจริงๆ... ช่วงนี้คุณรู้สึกปวดตึงไหล่หรือหัวตื้อร่วมด้วยไหมครับ? ลองหยุดพักสัก 2 นาทีแล้วคุยกับผมก่อนดีกว่า มีตรงไหนเป็นพิเศษที่ทำให้รู้สึกกังวลมากที่สุดในตอนนี้ครับ?",
        "ความกดดันจากการเตรียมสอบหรือเป้าหมายที่ตึงเครียดทำร้ายพลังงานเราได้ง่ายมากครับ... อยากให้คุณลองปล่อยวางสักแป๊บ วันนี้คุณพักผ่อนและดื่มน้ำเพียงพอหรือยังครับ? ลองเล่าให้ผมฟังหน่อยสิครับว่าอะไรคือสิ่งที่ทำให้คุณรู้สึกหนักใจที่สุดตอนนี้?",
        "เรียนหนักหรือทำงานหนักจนล้าใช่ไหมครับ? พลังใจของคุณมีความสำคัญมากนะ... ลองมาฝึกหายใจแบบ Box Breathing ด้วยกันสักครึ่งนาทีดีไหม หรือคุณอยากระบายเรื่องรายละเอียดของงาน/วิชาที่กำลังอ่านอยู่ให้ผมฟังก่อนครับ?"
      ],
      lonely: [
        "ความเหงาหรือความรู้สึกโดดเดี่ยวเป็นเรื่องที่หนักอึ้งมากครับ ขอบคุณมากๆ ที่วางใจบอกความรู้สึกนี้กับผมนะ... วันนี้เป็นอย่างไรบ้างครับ มีความรู้สึกนี้เกิดขึ้นตั้งแต่ตอนไหนเป็นพิเศษหรือเปล่าครับ? เผื่อเราลองมาหาทางผ่อนคลายไปด้วยกัน",
        "เวลาที่เราสู้คนเดียวหรือรู้สึกไม่มีใครเข้าใจ มันโดดเดี่ยวจริงๆ ครับ... ผมอยู่ตรงนี้เพื่อรับฟังคุณเสมอนะครับ มีกิจกรรมอะไรที่คุณชอบทำแล้วรู้สึกสบายใจบ้างไหมครับ หรืออยากให้ผมช่วยแนะนำบัดดี้ร่วมทางในแอปให้ดีครับ?",
        "ขอบคุณที่ระบายมันออกมานะครับ ความรู้สึกเศร้าหรือเหงามันผ่านมาและผ่านไปได้ครับ... ช่วงนี้ได้มีโอกาสคุยกับเพื่อนสนิทหรือคนในครอบครัวบ้างหรือยังครับ? หรือคุณอยากแชร์เรื่องราวในใจกับผมเพิ่มเติมตรงไหนไหมครับ?"
      ],
      default: [
        "สวัสดีครับ ยินดีต้อนรับสู่ MIND MERIT นะครับ ผมอยู่ตรงนี้เพื่อดูแลและรับฟังสุขภาพใจของคุณ วันนี้รู้สึกอย่างไรบ้างครับ? มีเรื่องอะไรที่อยากคุยกับผมเป็นพิเศษ หรือมีจุดไหนที่คุณรู้สึกไม่สบายใจอยู่ไหม ลองแชร์ให้ฟังหน่อยได้ไหมครับ?",
        "ยินดีต้อนรับกลับมาคุยกันนะครับ! สุขภาพใจของคุณวันนี้เป็นอย่างไรบ้าง? มีเรื่องราวดีๆ หรือเรื่องที่กังวลอยากชวนคุยไหมครับ ผมสงสัยจังว่าวันนี้คุณได้ทำสิ่งที่ชอบหรือยัง?",
        "สวัสดีครับเพื่อนร่วมทาง MIND MERIT วันนี้พกพาความรู้สึกแบบไหนมาหาผมเอ่ย? มีความเครียด ความเหงา หรือสิ่งที่คุณเพิ่งเจอมาอยากแชร์ไหมครับ? ผมพร้อมรับฟังและถามไถ่คุณเสมอครับ"
      ]
    };

    const englishReplies = {
      stress: [
        "I hear you, and I completely validate that pressure. Exam or work stress is incredibly exhausting... Have you noticed any physical tension, like tight shoulders or a headache? What is the single biggest thing that is weighing on your mind right now?",
        "Overthinking and pressure can drain your energy so quickly. Remember to take a deep breath. Have you been eating well and keeping hydrated today? Tell me a bit more about what's going on so we can unpack it together.",
        "That sounds like a heavy load to carry. Your mental health matters more than any exam or project. Would you like to try a quick 1-minute box breathing session with me, or would you prefer to vent about what is making you feel stuck?"
      ],
      lonely: [
        "Loneliness can feel so heavy and quiet. Thank you for opening up to me—you don't have to carry this alone. I am here to listen. When did you start feeling this way, and what usually helps bring a tiny bit of warmth to your day?",
        "It is completely okay to feel sad or disconnected sometimes. I'm right here with you. Do you have a favorite comfort hobby or music that makes you feel slightly better, or would you like to explore matching with a peer buddy in our community?",
        "Thank you for sharing your heart with me. I appreciate your trust. Have you had a chance to talk to any close friends or family recently, or would you like to chat more with me about what's on your mind today?"
      ],
      default: [
        "Hello and welcome back to MIND MERIT! I'm your dedicated AI well-being companion. How is your heart feeling today? What is on your mind that you would love to explore together?",
        "Welcome! It is great to connect with you. How has your day been so far? Did anything exciting, stressful, or interesting happen that you'd like to share with me?",
        "Greetings, my friend! I am here to listen and guide you through whatever you are experiencing. How was your sleep last night, and what can we do together to make your day feel lighter?"
      ]
    };

    const selectRandom = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];

    if (isThai) {
      if (msgLower.includes("เครียด") || msgLower.includes("สอบ") || msgLower.includes("งาน") || msgLower.includes("เหนื่อย")) {
        responseText = selectRandom(thaiReplies.stress);
      } else if (msgLower.includes("เหงา") || msgLower.includes("เศร้า") || msgLower.includes("คนเดียว") || msgLower.includes("ท้อ")) {
        responseText = selectRandom(thaiReplies.lonely);
      } else {
        responseText = selectRandom(thaiReplies.default);
      }
    } else {
      if (msgLower.includes("stress") || msgLower.includes("exam") || msgLower.includes("work") || msgLower.includes("study") || msgLower.includes("tired")) {
        responseText = selectRandom(englishReplies.stress);
      } else if (msgLower.includes("lonely") || msgLower.includes("sad") || msgLower.includes("alone") || msgLower.includes("down")) {
        responseText = selectRandom(englishReplies.lonely);
      } else {
        responseText = selectRandom(englishReplies.default);
      }
    }

    return res.json({ text: responseText });
  }

  try {
    // Format history cleanly for the modern @google/genai SDK
    // The history parameter is mapped to contents
    const contentsPayload = [];

    if (history && Array.isArray(history)) {
      for (const h of history) {
        contentsPayload.push({
          role: h.sender === 'user' ? 'user' : 'model',
          parts: [{ text: h.text }]
        });
      }
    }

    // Append the latest user message
    contentsPayload.push({
      role: 'user',
      parts: [{ text: message }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contentsPayload,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    return res.json({ text: response.text || "" });
  } catch (error: any) {
    console.error("Gemini Chat Error:", error);
    return res.status(500).json({ error: error.message || "Failed to communicate with AI" });
  }
});

// Mood Analysis API
app.post("/api/gemini/analyze-mood", async (req, res) => {
  const { mood, stress, sleep, exercise, gratitude, journal, language } = req.body;
  const isThai = language === 'th';

  const prompt = `Analyze this daily check-in:
- Mood: ${mood}
- Stress Level: ${stress}/10
- Sleep Duration: ${sleep} hours
- Exercise Duration: ${exercise} minutes
- Things grateful for: "${gratitude}"
- Personal Journal notes: "${journal}"

Please generate a comforting, insightful, and motivating feedback summary (2-3 sentences max) tailored for a student or working adult. Suggest one action they can take. Respond in ${isThai ? 'Thai' : 'English'}.`;

  const ai = getAIClient();

  if (!ai) {
    let mockResponse = "";
    if (isThai) {
      if (stress > 6 || mood === 'terrible' || mood === 'bad') {
        mockResponse = "ดูเหมือนว่าวันนี้จะเป็นวันที่ค่อนข้างหนักหน่วงสำหรับคุณนะครับ ด้วยความเครียดสะสมระดับสูง ${stress}/10 และเวลานอนที่อาจจะยังไม่เพียงพอ ผมขอแนะนำให้คุณลองหาเวลาสัก 10 นาทีเพื่อปลีกวิเวก ฝึกหายใจช้าๆ และดื่มน้ำอุ่นสักแก้วนะครับ คุณพยายามมาทั้งวันแล้ว เก่งมากแล้วครับ!";
      } else {
        mockResponse = "ยินดีด้วยครับที่คุณมีวันที่ดี! การออกกำลังกาย ${exercise} นาทีและจดบันทึกความรู้สึกดีๆ เป็นรากฐานที่ยอดเยี่ยมมากในการดูแลใจ รักษาจังหวะชีวิตที่มีสมดุลนี้ไว้ และขอให้วันพรุ่งนี้เป็นวันที่สดใสอีกวันนะครับ!";
      }
    } else {
      if (stress > 6 || mood === 'terrible' || mood === 'bad') {
        mockResponse = "It looks like today has been a challenging day with higher stress levels (${stress}/10). I encourage you to set aside all tasks for just 5 minutes and practice a simple box breathing cycle. You have worked hard today, and it is okay to rest!";
      } else {
        mockResponse = "Fantastic job on maintaining such a balanced routine today! Expressing gratitude and squeezing in ${exercise} minutes of physical activity is highly supportive of your mental well-being. Keep up this beautiful momentum!";
      }
    }
    return res.json({ text: mockResponse });
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are an empathetic psychologist analyzing daily health/mood check-in logs to offer light coaching feedback. Never diagnose clinical illness. Be supportive.",
        temperature: 0.6,
      }
    });

    return res.json({ text: response.text || "" });
  } catch (error: any) {
    console.error("Gemini Mood Analysis Error:", error);
    return res.status(500).json({ error: error.message || "Failed to analyze mood with AI" });
  }
});

// AI Wellbeing Recommendation Engine
app.post("/api/gemini/recommendations", async (req, res) => {
  const { stressScore, wellbeingScore, category, role, language } = req.body;
  const isThai = language === 'th';

  const prompt = `Based on the following assessment scores:
- Category evaluated: ${category}
- Stress Index Score: ${stressScore}/10
- Well-being Self-report Score: ${wellbeingScore}/100
- User occupation profile: ${role}

Please produce three highly practical, bite-sized daily recommendations (such as a mindfulness technique, a study/work tip, or a self-care habit). Format each recommendation as a short bullet point with a bold title. Reply in ${isThai ? 'Thai' : 'English'}.`;

  const ai = getAIClient();

  if (!ai) {
    let mockRecs = [];
    if (isThai) {
      mockRecs = [
        "**1. เทคนิคผ่อนคลายด่วน (Box Breathing)**: เมื่อรู้สึกเครียดหรือสมาธิหลุด ให้ลึกหายใจเข้า 4 วินาที กลั้นไว้ 4 วินาที หายใจออก 4 วินาที และกลั้นไว้อีก 4 วินาที ทำติดต่อกัน 4-5 รอบเพื่อคืนสมาธิให้กับระบบประสาท",
        "**2. กฎการเว้นระยะพัก (Pomodoro 25/5)**: สำหรับคนทำงานหรือนักเรียน ให้ทำงานตั้งใจ 25 นาที แล้วพักสายตา ยืดเส้นยืดสาย 5 นาที เพื่อป้องกันความเหนื่อยล้าทางสมองสะสม",
        "**3. สื่อสารกับบัดดี้ (Share a Streak)**: แบ่งปันความก้าวหน้าในการทำกิจกรรมสมาธิหรือความรู้สึกวันนี้กับคู่บัดดี้ของคุณในแพลตฟอร์ม เพื่อรับพลังบวกและความรู้สึกเชื่อมโยงทางสังคม"
      ];
    } else {
      mockRecs = [
        "**1. Box Breathing Practice**: When you feel stress rising, inhale for 4 seconds, hold for 4, exhale for 4, and hold for 4. Repeat 4 times to instantly soothe your nervous system.",
        "**2. Pomodoro Break Method**: Work/study with full focus for 25 minutes, then force a 5-minute offline break. This is highly effective at staving off mental fatigue and burnout.",
        "**3. Buddy Synergy Check-in**: Drop a positive note or share your habit streak with your matched well-being buddy. Social connection is a robust buffer against loneliness and overthinking."
      ];
    }
    return res.json({ recommendations: mockRecs });
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are a wellness coach generating highly tailored recommendations for students or working adults. Deliver only three short, motivational, bullet-pointed recommendations with bold titles.",
        temperature: 0.5,
      }
    });

    const text = response.text || "";
    // Parse response into array of bullets
    const recommendations = text.split('\n').filter(line => line.trim().length > 0);
    return res.json({ recommendations: recommendations.slice(0, 3) });
  } catch (error: any) {
    console.error("Gemini Recommendations Error:", error);
    return res.status(500).json({ error: error.message || "Failed to generate recommendations" });
  }
});

// Configure Vite middleware and static serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
