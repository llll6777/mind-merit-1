import { useState, useEffect } from "react";
import { 
  LayoutDashboard, 
  BookOpen, 
  Bot, 
  ClipboardList, 
  GraduationCap, 
  Users, 
  ShieldAlert, 
  Settings, 
  FileText 
} from "lucide-react";

import Header from "./components/Header";
import DashboardView from "./components/DashboardView";
import MoodCheckInView from "./components/MoodCheckInView";
import ChatbotView from "./components/ChatbotView";
import AssessmentView from "./components/AssessmentView";
import LearningView from "./components/LearningView";
import CommunityView from "./components/CommunityView";
import SOSView from "./components/SOSView";
import AdminView from "./components/AdminView";
import DocsView from "./components/DocsView";

import { UserProfile, MoodCheckIn, Badge, Post, Certificate, ChatMessage } from "./types";
import { translations } from "./translations";

export default function App() {
  // 1. Core Profile State
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem("mind_merit_profile_v1");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error parsing profile from local storage:", e);
      }
    }
    return {
      name: "ผู้ใช้ใหม่",
      age: 19,
      role: "student",
      xp: 0,
      level: 1,
      streak: 0, // Initial streak is 0 as requested!
      badges: ["welcome_badge"],
      language: "th", // default to Thai as requested
      theme: "light",
      pdpaConsent: true,
      anonymousMode: true,
      visitsToday: 0,
      lastVisitDate: ""
    };
  });

  const [activeTab, setActiveTab] = useState<string>("dashboard");

  // Track daily visits and increase streak accordingly
  useEffect(() => {
    const todayStr = new Date().toISOString().split("T")[0];
    setUser(prev => {
      let updatedStreak = prev.streak;
      let updatedVisitsToday = prev.visitsToday || 0;
      
      if (prev.lastVisitDate === todayStr) {
        // Same day visit: increment visits today, and increment streak on each visit!
        updatedVisitsToday += 1;
        updatedStreak += 1; // streak increases according to visit count per day
      } else {
        // New day visit (or first-ever launch):
        updatedVisitsToday = 1;
        // On a new day, streak is also incremented by 1 for visiting
        updatedStreak += 1;
      }

      return {
        ...prev,
        visitsToday: updatedVisitsToday,
        streak: updatedStreak,
        lastVisitDate: todayStr
      };
    });
  }, []);

  // Sync state changes to localStorage
  useEffect(() => {
    localStorage.setItem("mind_merit_profile_v1", JSON.stringify(user));
  }, [user]);

  // Apply Theme class directly to Document body/HTML
  useEffect(() => {
    const root = window.document.documentElement;
    if (user.theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  }, [user.theme]);

  // 2. Health & Mood check-in records state
  const [moodLogs, setMoodLogs] = useState<MoodCheckIn[]>(() => {
    const saved = localStorage.getItem("mind_merit_mood_logs_v1");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error parsing mood logs:", e);
      }
    }
    // Pre-seeded with recent days for rendering trend lines
    return [
      {
        id: "log-seed-1",
        date: "2026-07-14",
        mood: "neutral",
        stress: 6,
        sleep: 6,
        exercise: 0,
        water: 500,
        studyWork: "overwhelmed",
        gratitude: "Having good noodles",
        journal: "Heavy study sessions today.",
        aiAnalysis: "You are handling heavy studies with good focus, but try to rest and drink more water!"
      },
      {
        id: "log-seed-2",
        date: "2026-07-15",
        mood: "bad",
        stress: 8,
        sleep: 4.5,
        exercise: 15,
        water: 750,
        studyWork: "overwhelmed",
        gratitude: "A brief walk",
        journal: "Anxiety about mock exams.",
        aiAnalysis: "Sleep deprivation of 4.5 hours is exacerbating exam stress. Prioritize early rest!"
      },
      {
        id: "log-seed-3",
        date: "2026-07-16",
        mood: "good",
        stress: 4,
        sleep: 7.5,
        exercise: 30,
        water: 1250,
        studyWork: "focused",
        gratitude: "Tutor help",
        journal: "Felt much more clear-headed after sleeping.",
        aiAnalysis: "Superb alignment of sleep (7.5h) and exercise (30m). Your stress level reduced to 4/10."
      },
      {
        id: "log-seed-4",
        date: "2026-07-17",
        mood: "excellent",
        stress: 2,
        sleep: 8,
        exercise: 25,
        water: 1500,
        studyWork: "balanced",
        gratitude: "Talking with my matched buddy",
        journal: "Met a supportive friend online.",
        aiAnalysis: "Fostering peer connections is an exceptional self-care booster. Your mood index is excellent today."
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem("mind_merit_mood_logs_v1", JSON.stringify(moodLogs));
  }, [moodLogs]);

  // 3. AI Counselor Chat History state
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem("mind_merit_chat_history_v1");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error parsing chat history:", e);
      }
    }
    return [
      {
        id: "chat-seed-1",
        sender: "ai",
        text: "สวัสดีครับ ยินดีต้อนรับสู่ MIND MERIT! ผมคือเพื่อนและนักจิตวิทยา AI ประจำตัวของคุณ วันนี้มีเรื่องราวอะไรที่คุณอยากเล่าให้ผมฟัง หรือมีจุดไหนที่คุณรู้สึกไม่สบายใจอยู่ไหมครับ? ผมพร้อมรับฟังและเคียงข้างคุณเสมอครับ",
        timestamp: "19:04"
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem("mind_merit_chat_history_v1", JSON.stringify(chatHistory));
  }, [chatHistory]);

  // 4. Community Support Posts state
  const [posts, setPosts] = useState<Post[]>(() => {
    const saved = localStorage.getItem("mind_merit_posts_v1");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error parsing posts:", e);
      }
    }
    return [
      {
        id: "post-1",
        author: "Student Explorer (บัดดี้สู้ชีวิต)",
        anonymous: false,
        content: "สู้ๆ นะครับทุกคนสำหรับสัปดาห์สอบมิดเทอมนี้! ถ้าเริ่มรู้สึกหัวตื้อหรือสมองล้า แนะนำให้ละสายตาจากตำราเรียนสัก 5 นาที แล้วทำ Box Breathing ลมหายใจเข้าลึกๆ ช่วยลดความวิตกกังวลได้เยอะมากจริงๆ ครับ 🌸",
        timestamp: "2 hours ago",
        likes: 12,
        likedByUser: false,
        comments: [
          { id: "comm-1", author: "Anonymous", anonymous: true, content: "ขอบคุณสำหรับพลังบวกและข้อคิดที่ดีมากๆ เลยค่ะ!", timestamp: "1 hour ago" }
        ]
      },
      {
        id: "post-2",
        author: "กระต่ายไม่ประสงค์ออกนาม",
        anonymous: true,
        content: "รู้สึกหมดไฟในการทำงานมากๆ เลยช่วงนี้ พองานกองเยอะก็เครียดจนหัวสมองตึงนอนไม่ค่อยหลับ มีใครมีคำแนะนำสำหรับอาการ Burnout บ้างไหมคะ? ☁️",
        timestamp: "5 hours ago",
        likes: 8,
        likedByUser: false,
        comments: []
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem("mind_merit_posts_v1", JSON.stringify(posts));
  }, [posts]);

  // 5. Unlocked Certificates state
  const [certificates, setCertificates] = useState<Certificate[]>(() => {
    const saved = localStorage.getItem("mind_merit_certificates_v1");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error parsing certificates:", e);
      }
    }
    return [];
  });

  useEffect(() => {
    localStorage.setItem("mind_merit_certificates_v1", JSON.stringify(certificates));
  }, [certificates]);

  // System Badge Definitions
  const systemBadges: Badge[] = [
    { id: "welcome_badge", titleEn: "Mindful Starter", titleTh: "ผู้เริ่มต้นฝึกสมาธิ", descEn: "Triggered on starting Mind Merit session.", descTh: "มอบให้เมื่อเริ่มต้นใช้งาน Mind Merit", icon: "Zap" },
    { id: "streak_champion", titleEn: "Streak Champion", titleTh: "แชมป์บันทึกอารมณ์", descEn: "Unlocked for active wellness streak.", descTh: "มอบให้เมื่อเช็คอินสุขภาพใจติดต่อกัน", icon: "Award" },
    { id: "assessment_guru", titleEn: "Assessment Guru", titleTh: "ผู้รอบรู้สุขภาพใจ", descEn: "Earned on completing psychometric checks.", descTh: "มอบให้เมื่อผ่านการวัดระดับสุขภาพใจทางวิทยาศาสตร์", icon: "BookOpen" },
    { id: "stress_warrior", titleEn: "Stress Warrior", titleTh: "ผู้พิชิตความตึงเครียด", descEn: "Earned on stress course graduation.", descTh: "มอบให้เมื่อผ่านหลักสูตรจัดการความเครียด", icon: "ShieldAlert" }
  ];

  const t = translations[user.language];

  // Callback utilities
  const handleRewardXP = (amount: number) => {
    setUser((prev) => {
      const newXp = prev.xp + amount;
      const leveledUp = newXp >= prev.level * 100;
      return {
        ...prev,
        xp: leveledUp ? newXp - prev.level * 100 : newXp,
        level: leveledUp ? prev.level + 1 : prev.level
      };
    });
  };

  const handleUnlockBadge = (badgeId: string) => {
    if (user.badges.includes(badgeId)) return;
    setUser((prev) => ({
      ...prev,
      badges: [...prev.badges, badgeId]
    }));
  };

  const handleAddLog = (newLog: MoodCheckIn) => {
    setMoodLogs((prev) => [...prev, newLog]);
    // Auto unlock streak badge if logs count > 4
    if (moodLogs.length >= 4) {
      handleUnlockBadge("streak_champion");
    }
  };

  const handleAddChatMessage = (msg: ChatMessage) => {
    setChatHistory((prev) => [...prev, msg]);
  };

  const handleAddPost = (newPost: Post) => {
    setPosts((prev) => [newPost, ...prev]);
  };

  const handleAddComment = (postId: string, text: string) => {
    setPosts((prev) => prev.map((p) => {
      if (p.id === postId) {
        return {
          ...p,
          comments: [...p.comments, {
            id: Math.random().toString(),
            author: user.anonymousMode ? (user.language === 'en' ? "Anonymous Buddy" : "บัดดี้ร่วมทาง") : user.name,
            anonymous: user.anonymousMode,
            content: text,
            timestamp: "Just now"
          }]
        };
      }
      return p;
    }));
  };

  const handleLikePost = (postId: string) => {
    setPosts((prev) => prev.map((p) => {
      if (p.id === postId) {
        return {
          ...p,
          likes: p.likedByUser ? p.likes - 1 : p.likes + 1,
          likedByUser: !p.likedByUser
        };
      }
      return p;
    }));
  };

  const handleAddCertificate = (newCert: Certificate) => {
    setCertificates((prev) => [...prev, newCert]);
    
    // Auto-unlock specific badge depending on course name
    if (newCert.courseNameEn.includes("Stress")) {
      handleUnlockBadge("stress_warrior");
    }
  };

  // Nav items definitions
  const sidebarNavItems = [
    { id: "dashboard", label: t.nav.dashboard, icon: LayoutDashboard },
    { id: "moodCheck", label: t.nav.moodCheck, icon: BookOpen },
    { id: "aiChat", label: t.nav.aiChat, icon: Bot },
    { id: "assessments", label: t.nav.assessments, icon: ClipboardList },
    { id: "academy", label: t.nav.academy, icon: GraduationCap },
    { id: "community", label: t.nav.community, icon: Users },
    { id: "admin", label: t.nav.admin, icon: Settings },
    { id: "docs", label: t.nav.docs, icon: FileText }
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 dark:bg-slate-950 dark:text-slate-100 font-sans transition-colors duration-300">
      
      {/* 1. Header Integration */}
      <Header 
        user={user} 
        onChangeLanguage={(lang) => setUser(prev => ({ ...prev, language: lang }))}
        onChangeTheme={(theme) => setUser(prev => ({ ...prev, theme: theme }))}
        onOpenSOS={() => setActiveTab("sos")}
      />

      {/* 2. Full-Stack Layout Canvas */}
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <div id="fullstack-grid" className="grid gap-6 md:grid-cols-4 items-start">
          
          {/* Left Navigation Menu (Desktop Sidebar) */}
          <nav id="desktop-sidebar-nav" className="hidden md:flex md:flex-col space-y-1 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/80 rounded-2xl p-3 shadow-sm">
            {sidebarNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-2.5 text-left text-xs font-bold rounded-xl transition-all cursor-pointer ${isActive ? 'bg-purple-100/60 text-purple-600 dark:bg-purple-950/25 dark:text-purple-300 border-l-4 border-purple-500' : 'text-slate-500 hover:bg-slate-50 dark:text-slate-400 dark:hover:bg-slate-800'}`}
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Core Content viewport (Takes 3/4 space on desktop) */}
          <main id="main-content-viewport" className="md:col-span-3">
            {activeTab === "dashboard" && (
              <DashboardView 
                user={user} 
                moodLogs={moodLogs} 
                badges={systemBadges} 
                onNavigate={(tab) => setActiveTab(tab)}
                onUpdateUser={setUser}
              />
            )}

            {activeTab === "moodCheck" && (
              <MoodCheckInView 
                user={user} 
                onAddLog={handleAddLog} 
                onRewardXP={handleRewardXP}
              />
            )}

            {activeTab === "aiChat" && (
              <ChatbotView 
                user={user} 
                chatHistory={chatHistory} 
                onAddChatMessage={handleAddChatMessage}
              />
            )}

            {activeTab === "assessments" && (
              <AssessmentView 
                user={user} 
                onRewardXP={handleRewardXP} 
                onUnlockBadge={handleUnlockBadge}
              />
            )}

            {activeTab === "academy" && (
              <LearningView 
                user={user} 
                onRewardXP={handleRewardXP} 
                onAddCertificate={handleAddCertificate}
                certificates={certificates}
              />
            )}

            {activeTab === "community" && (
              <CommunityView 
                user={user} 
                onRewardXP={handleRewardXP} 
                posts={posts} 
                onAddPost={handleAddPost} 
                onAddComment={handleAddComment} 
                onLikePost={handleLikePost}
              />
            )}

            {activeTab === "sos" && (
              <SOSView user={user} />
            )}

            {activeTab === "admin" && (
              <AdminView user={user} certificates={certificates} />
            )}

            {activeTab === "docs" && (
              <DocsView user={user} />
            )}
          </main>

        </div>
      </div>

      {/* 3. Mobile Navigation Bottom Tab Bar */}
      <nav id="mobile-tab-nav" className="sticky bottom-0 z-40 w-full border-t border-slate-100 bg-white dark:border-slate-800 dark:bg-slate-900 md:hidden py-2 flex justify-around">
        {sidebarNavItems.slice(0, 6).map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center text-[10px] font-bold ${isActive ? 'text-purple-600 dark:text-purple-400' : 'text-slate-400'}`}
            >
              <Icon className="h-4 w-4" />
              <span className="mt-0.5">{item.label.split(" ")[0]}</span>
            </button>
          );
        })}
      </nav>

    </div>
  );
}
