import { Sun, Moon, Languages, Award, ShieldAlert } from "lucide-react";
import { UserProfile } from "../types";
import { translations } from "../translations";

interface HeaderProps {
  user: UserProfile;
  onChangeLanguage: (lang: 'en' | 'th') => void;
  onChangeTheme: (theme: 'light' | 'dark') => void;
  onOpenSOS: () => void;
}

export default function Header({ user, onChangeLanguage, onChangeTheme, onOpenSOS }: HeaderProps) {
  const t = translations[user.language];

  const toggleLanguage = () => {
    onChangeLanguage(user.language === 'en' ? 'th' : 'en');
  };

  const toggleTheme = () => {
    onChangeTheme(user.theme === 'light' ? 'dark' : 'light');
  };

  const xpProgress = (user.xp % 100);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-purple-100/40 bg-white/75 backdrop-blur-md dark:border-slate-800/40 dark:bg-slate-900/75 transition-colors duration-300">
      <div id="app-header-container" className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Brand Logo & Name */}
        <div id="brand-logo-section" className="flex items-center space-x-3 cursor-pointer">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-300 via-purple-300 to-pink-300 shadow-md">
            <span className="font-sans text-xl font-bold text-white tracking-wider">M</span>
          </div>
          <div>
            <h1 className="font-sans text-lg font-bold tracking-tight text-slate-800 dark:text-slate-100">
              {t.appName}
            </h1>
            <p className="hidden text-[10px] text-slate-400 dark:text-slate-500 sm:block">
              {t.tagline}
            </p>
          </div>
        </div>

        {/* Middle Status Bars (XP / Level) */}
        <div id="header-user-status" className="hidden items-center space-x-6 md:flex">
          <div className="flex items-center space-x-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-yellow-50 dark:bg-yellow-950/30 text-yellow-500">
              <Award className="h-4 w-4" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  Lv. {user.level}
                </span>
                <span className="text-[10px] text-slate-400 dark:text-slate-500">
                  {user.xp} XP
                </span>
              </div>
              <div className="h-1.5 w-24 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                <div 
                  className="h-full bg-gradient-to-r from-yellow-400 to-amber-300 transition-all duration-500" 
                  style={{ width: `${xpProgress}%` }}
                />
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-1.5 rounded-full bg-orange-50 px-3 py-1 text-orange-600 dark:bg-orange-950/20 dark:text-orange-400">
            <span className="text-xs font-bold">🔥 {user.streak} {user.language === 'en' ? 'Days' : 'วัน'}</span>
          </div>
        </div>

        {/* Action Controls */}
        <div id="header-controls" className="flex items-center space-x-2">
          {/* Quick SOS Trigger Button */}
          <button
            id="quick-sos-btn"
            onClick={onOpenSOS}
            className="flex items-center space-x-1.5 rounded-xl bg-rose-50 px-3 py-2 text-rose-600 shadow-sm hover:bg-rose-100 dark:bg-rose-950/30 dark:text-rose-400 dark:hover:bg-rose-900/30 transition-all"
          >
            <ShieldAlert className="h-4 w-4 animate-pulse" />
            <span className="text-xs font-bold tracking-wide">SOS</span>
          </button>

          {/* Language Toggle */}
          <button
            id="language-toggle-btn"
            onClick={toggleLanguage}
            title={user.language === 'en' ? 'Switch to Thai' : 'Switch to English'}
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-100 bg-slate-50 text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 transition-all"
          >
            <Languages className="h-4 w-4" />
          </button>

          {/* Theme Toggle */}
          <button
            id="theme-toggle-btn"
            onClick={toggleTheme}
            title={user.theme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-100 bg-slate-50 text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 transition-all"
          >
            {user.theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
          </button>

          {/* Mini Avatar */}
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-50 text-purple-600 font-bold text-sm border border-purple-100 dark:bg-purple-950/20 dark:text-purple-300 dark:border-purple-900/30">
            {user.name.charAt(0).toUpperCase()}
          </div>
        </div>

      </div>
    </header>
  );
}
